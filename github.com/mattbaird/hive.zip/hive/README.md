hive
====

thrift hive generated code
